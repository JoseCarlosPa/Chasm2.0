<?php $__env->startSection('title','List Products'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="header_container">
        <br><br><br><br><br><br><br><br><br><br>
    </div>
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <?php echo $__env->make('frontEnd.layouts.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-sm-9 padding-right">
                <div class="features_items"><!--features_items-->
                    <?php
                            if($byCate!=""){
                                $products=$list_product;
                                echo '<h2 class="title text-center">Categoria '.$byCate->name.'</h2>';
                            }else{
                                echo '<h2 class="title text-center">Lista de Productos</h2>';
                            }
                    ?>
                    <div class ="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($product->category->status==1): ?>
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper card card_shadow">
                                        <div class="single-products">
                                            <a href="<?php echo e(url('/product-detail',$product->id)); ?>" style ="color: white"><div class="trapezoid3 "><p style="padding-top: 10%">Comprar</p></div></a><br><br>
                                            <div class="productinfo text-center">
                                                <a href="<?php echo e(url('/product-detail',$product->id)); ?>"><img src="<?php echo e(url('products/small/',$product->image)); ?>" alt="" width="30em" height="200em"/></a>
                                                <br><br>
                                                <h2><img src="<?php echo e(asset('frontEnd/imgs/miniaturas/carrito.svg')); ?>" alt="" width="3em"
                                                         height="40px"/> <br><br>$</a> <?php echo e($product->price); ?></h2>
                                                <p><?php echo e($product->p_name); ?></p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    
                </div><!--features_items-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>