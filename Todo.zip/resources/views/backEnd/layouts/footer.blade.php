<div class="row-fluid">
    <div id="footer" class="span12">Copyright ©2019 Laravel5.7 (UpyouGo). Todos los derechos reservados.</div>
</div>
